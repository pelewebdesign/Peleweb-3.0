<?php
/**
 * Thème headless : WordPress n'affiche aucune page publique.
 * Toute visite du site WordPress (hors admin et API) est redirigée
 * vers le site Astro défini dans wp-config.php (PELEWEB_FRONTEND_URL).
 */

if ( defined( 'PELEWEB_FRONTEND_URL' ) && PELEWEB_FRONTEND_URL ) {
	wp_redirect( PELEWEB_FRONTEND_URL, 302 );
	exit;
}
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow">
<title>Peleweb — CMS</title>
<style>body{font-family:system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;margin:0;background:#0D0A1C;color:#fff}a{color:#D4FF3F}</style>
</head>
<body>
<p>Ce WordPress sert uniquement à gérer les contenus. <a href="<?php echo esc_url( admin_url() ); ?>">Accéder à l’administration</a></p>
</body>
</html>
