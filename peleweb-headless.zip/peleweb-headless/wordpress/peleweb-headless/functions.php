<?php
/**
 * Peleweb Headless — fonctions du thème.
 *
 * À ajouter dans wp-config.php (au-dessus de « C'est tout, ne touchez pas à ce qui suit ») :
 *
 *   define( 'PELEWEB_FRONTEND_URL', 'https://peleweb.com' );
 *   define( 'PELEWEB_BUILD_HOOK', 'https://api.netlify.com/build_hooks/VOTRE_IDENTIFIANT' );
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/inc/post-types.php';
require_once __DIR__ . '/inc/fields.php';
require_once __DIR__ . '/inc/rest.php';
require_once __DIR__ . '/inc/build-hook.php';
require_once __DIR__ . '/inc/seed.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );

	// Captures des projets : 1440 × 900 (écrans haute définition) et 720 × 450 (mobile).
	add_image_size( 'pw-shot', 1440, 900, true );
	add_image_size( 'pw-shot-sm', 720, 450, true );
} );

// Le CMS ne doit pas être indexé par Google : seul le site Astro compte.
add_action( 'wp_head', function () {
	echo '<meta name="robots" content="noindex, nofollow">' . "\n";
} );

// Avertissement si Advanced Custom Fields n'est pas activé.
add_action( 'admin_notices', function () {
	if ( function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p><strong>Peleweb :</strong> installez et activez l’extension gratuite « Advanced Custom Fields » pour afficher les champs des projets, avis, FAQ et formules.</p></div>';
} );

// Menu d'administration simplifié : on masque ce qui ne sert pas en headless.
add_action( 'admin_menu', function () {
	remove_menu_page( 'edit.php' );          // Articles
	remove_menu_page( 'edit-comments.php' ); // Commentaires
}, 999 );

// Les SVG ne sont pas acceptés par défaut : on les autorise pour les logos clients (administrateurs uniquement).
add_filter( 'upload_mimes', function ( $mimes ) {
	if ( current_user_can( 'manage_options' ) ) {
		$mimes['svg'] = 'image/svg+xml';
	}
	return $mimes;
} );
add_filter( 'wp_check_filetype_and_ext', function ( $data, $file, $filename, $mimes ) {
	if ( current_user_can( 'manage_options' ) && strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) === 'svg' ) {
		$data['ext']  = 'svg';
		$data['type'] = 'image/svg+xml';
	}
	return $data;
}, 10, 4 );
