<?php
/**
 * Point d'API unique lu par Astro au moment de construire le site :
 *   GET /wp-json/peleweb/v1/content
 *
 * Il renvoie tous les contenus publiés, déjà mis en forme (FR, EN et ES).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'peleweb/v1', '/content', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true', // Lecture publique des contenus publiés uniquement.
		'callback'            => 'pw_rest_content',
	) );
} );

function pw_meta( $id, $key ) {
	return trim( (string) get_post_meta( $id, $key, true ) );
}

function pw_bool( $id, $key ) {
	return '1' === (string) get_post_meta( $id, $key, true );
}

/** Texte dans les trois langues : { fr, en, es }. */
function pw_l( $id, $base ) {
	return array(
		'fr' => pw_meta( $id, $base . '_fr' ),
		'en' => pw_meta( $id, $base . '_en' ),
		'es' => pw_meta( $id, $base . '_es' ),
	);
}

function pw_lines( $text ) {
	$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
	return array_values( array_filter( array_map( 'trim', $lines ), 'strlen' ) );
}

function pw_posts( $type ) {
	return get_posts( array(
		'post_type'        => $type,
		'post_status'      => 'publish',
		'numberposts'      => -1,
		'orderby'          => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
		'suppress_filters' => false,
	) );
}

function pw_image( $id, $size ) {
	$thumb = get_post_thumbnail_id( $id );
	if ( ! $thumb ) {
		return null;
	}
	$url = wp_get_attachment_image_url( $thumb, $size );
	return $url ? $url : wp_get_attachment_url( $thumb );
}

function pw_rest_content() {
	$out = array(
		'clients'  => array(),
		'projects' => array(),
		'reviews'  => array(),
		'faq'      => array(),
		'pricing'  => array(),
	);

	foreach ( pw_posts( 'pw_client' ) as $p ) {
		$out['clients'][] = array(
			'name' => get_the_title( $p ),
			'logo' => pw_image( $p->ID, 'full' ),
		);
	}

	foreach ( pw_posts( 'pw_projet' ) as $p ) {
		$out['projects'][] = array(
			'name'        => get_the_title( $p ),
			'url'         => pw_meta( $p->ID, 'url' ),
			'domain'      => pw_meta( $p->ID, 'domaine' ),
			'image'       => pw_image( $p->ID, 'pw-shot' ),
			'image_small' => pw_image( $p->ID, 'pw-shot-sm' ),
			'type'        => pw_l( $p->ID, 'type' ),
			'desc'        => pw_l( $p->ID, 'description' ),
		);
	}

	foreach ( pw_posts( 'pw_avis' ) as $p ) {
		$out['reviews'][] = array(
			'name'     => get_the_title( $p ),
			'company'  => pw_meta( $p->ID, 'entreprise' ),
			'quote'    => pw_l( $p->ID, 'citation' ),
			'featured' => pw_bool( $p->ID, 'mis_en_avant' ),
			'logo'     => pw_image( $p->ID, 'medium' ),
		);
	}

	foreach ( pw_posts( 'pw_faq' ) as $p ) {
		$out['faq'][] = array(
			'question' => array( 'fr' => get_the_title( $p ), 'en' => pw_meta( $p->ID, 'question_en' ), 'es' => pw_meta( $p->ID, 'question_es' ) ),
			'answer'   => pw_l( $p->ID, 'reponse' ),
			'open'     => pw_bool( $p->ID, 'ouverte' ),
		);
	}

	foreach ( pw_posts( 'pw_formule' ) as $p ) {
		$out['pricing'][] = array(
			'name'     => array( 'fr' => get_the_title( $p ), 'en' => pw_meta( $p->ID, 'nom_en' ), 'es' => pw_meta( $p->ID, 'nom_es' ) ),
			'desc'     => pw_l( $p->ID, 'description' ),
			'price'    => pw_l( $p->ID, 'prix' ),
			'items'    => array(
				'fr' => pw_lines( pw_meta( $p->ID, 'elements_fr' ) ),
				'en' => pw_lines( pw_meta( $p->ID, 'elements_en' ) ),
				'es' => pw_lines( pw_meta( $p->ID, 'elements_es' ) ),
			),
			'featured' => pw_bool( $p->ID, 'mise_en_avant' ),
		);
	}

	$response = rest_ensure_response( $out );
	$response->header( 'Cache-Control', 'no-store' );
	return $response;
}
