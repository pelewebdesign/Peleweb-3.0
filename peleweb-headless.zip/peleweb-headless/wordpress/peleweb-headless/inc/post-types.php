<?php
/**
 * Types de contenus gérés dans l'admin.
 * L'ordre d'affichage sur le site suit le champ « Ordre » (Attributs) de chaque contenu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {

	$types = array(
		'pw_projet'  => array( 'Projets', 'Projet', 'dashicons-portfolio', array( 'title', 'thumbnail', 'page-attributes' ), 'Nom du projet' ),
		'pw_client'  => array( 'Clients (logos)', 'Client', 'dashicons-groups', array( 'title', 'thumbnail', 'page-attributes' ), 'Nom du client' ),
		'pw_avis'    => array( 'Avis clients', 'Avis', 'dashicons-format-quote', array( 'title', 'thumbnail', 'page-attributes' ), 'Prénom et nom du client' ),
		'pw_formule' => array( 'Formules', 'Formule', 'dashicons-tag', array( 'title', 'page-attributes' ), 'Nom de la formule (français)' ),
		'pw_faq'     => array( 'FAQ', 'Question', 'dashicons-editor-help', array( 'title', 'page-attributes' ), 'Question (français)' ),
	);

	$position = 20;
	foreach ( $types as $slug => $t ) {
		register_post_type( $slug, array(
			'labels'          => array(
				'name'               => $t[0],
				'singular_name'      => $t[1],
				'add_new'            => 'Ajouter',
				'add_new_item'       => 'Ajouter : ' . $t[1],
				'edit_item'          => 'Modifier : ' . $t[1],
				'new_item'           => 'Nouveau',
				'search_items'       => 'Rechercher',
				'not_found'          => 'Aucun élément',
				'not_found_in_trash' => 'Aucun élément dans la corbeille',
				'featured_image'     => 'pw_projet' === $slug ? 'Capture du site (1440 × 900)' : 'Logo',
				'set_featured_image' => 'Choisir l’image',
				'remove_featured_image' => 'Retirer l’image',
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_rest'    => false, // Éditeur classique : titre + champs, sans blocs.
			'menu_position'   => $position++,
			'menu_icon'       => $t[2],
			'supports'        => $t[3],
			'hierarchical'    => false,
			'has_archive'     => false,
			'rewrite'         => false,
		) );
	}
} );

// Texte d'aide dans le champ titre.
add_filter( 'enter_title_here', function ( $text, $post ) {
	$hints = array(
		'pw_projet'  => 'Nom du projet',
		'pw_client'  => 'Nom du client',
		'pw_avis'    => 'Prénom et nom du client',
		'pw_formule' => 'Nom de la formule (français)',
		'pw_faq'     => 'Question (français)',
	);
	return $hints[ $post->post_type ] ?? $text;
}, 10, 2 );

// Les listes de l'admin sont triées par ordre d'affichage.
add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( in_array( $query->get( 'post_type' ), array( 'pw_projet', 'pw_client', 'pw_avis', 'pw_formule', 'pw_faq' ), true ) && ! $query->get( 'orderby' ) ) {
		$query->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'ASC' ) );
	}
} );
