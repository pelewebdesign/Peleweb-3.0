<?php
/**
 * Outils › Contenus Peleweb : importe en un clic les contenus de départ
 * (projets, clients, avis, FAQ, formules) depuis seed.json.
 * L'import ne crée que les types encore vides : il ne remplace jamais vos contenus.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_management_page( 'Contenus Peleweb', 'Contenus Peleweb', 'manage_options', 'pw-seed', 'pw_seed_page' );
} );

function pw_seed_page() {
	$done = isset( $_GET['pw_seeded'] ) ? (int) $_GET['pw_seeded'] : null;
	echo '<div class="wrap"><h1>Contenus Peleweb</h1>';
	if ( null !== $done ) {
		echo '<div class="notice notice-success"><p>' . esc_html( $done ) . ' contenus importés.</p></div>';
	}
	echo '<p>Importe les contenus de départ du site : projets, clients, avis, FAQ et formules (textes en FR, EN et ES).<br>Les images (captures et logos) sont à ajouter ensuite dans chaque contenu, via « Image mise en avant ».<br>Seuls les types encore vides sont remplis : vos contenus existants ne sont jamais modifiés.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'pw_seed' );
	echo '<input type="hidden" name="action" value="pw_seed">';
	submit_button( 'Importer les contenus de départ' );
	echo '</form></div>';
}

function pw_seed_meta( $post_id, $group, $values ) {
	foreach ( $values as $name => $value ) {
		update_post_meta( $post_id, $name, $value );
		update_post_meta( $post_id, '_' . $name, 'field_pw_' . $group . '_' . $name ); // Référence ACF.
	}
}

function pw_seed_insert( $type, $title, $order ) {
	return wp_insert_post( array(
		'post_type'   => $type,
		'post_title'  => $title,
		'post_status' => 'publish',
		'menu_order'  => $order,
	) );
}

function pw_seed_is_empty( $type ) {
	return ! get_posts( array( 'post_type' => $type, 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) );
}

add_action( 'admin_post_pw_seed', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'pw_seed' ) ) {
		wp_die( 'Action non autorisée.' );
	}
	$data = json_decode( (string) file_get_contents( get_template_directory() . '/seed.json' ), true );
	if ( ! is_array( $data ) ) {
		wp_die( 'Fichier seed.json introuvable ou invalide.' );
	}

	// Pas de reconstruction Netlify pour chaque contenu : une seule à la fin.
	set_transient( 'pw_build_lock', 1, MINUTE_IN_SECONDS );
	$count = 0;

	if ( pw_seed_is_empty( 'pw_client' ) ) {
		foreach ( $data['clients'] as $i => $c ) {
			pw_seed_insert( 'pw_client', $c['name'], $i ) && $count++;
		}
	}

	if ( pw_seed_is_empty( 'pw_projet' ) ) {
		foreach ( $data['projects'] as $i => $p ) {
			$id = pw_seed_insert( 'pw_projet', $p['name'], $i );
			if ( ! $id ) {
				continue;
			}
			pw_seed_meta( $id, 'projet', array(
				'url'            => $p['url'],
				'domaine'        => $p['domain'],
				'type_fr'        => $p['type']['fr'],
				'type_en'        => $p['type']['en'],
				'type_es'        => $p['type']['es'],
				'description_fr' => $p['desc']['fr'],
				'description_en' => $p['desc']['en'],
				'description_es' => $p['desc']['es'],
			) );
			$count++;
		}
	}

	if ( pw_seed_is_empty( 'pw_avis' ) ) {
		foreach ( $data['reviews'] as $i => $r ) {
			$id = pw_seed_insert( 'pw_avis', $r['name'], $i );
			if ( ! $id ) {
				continue;
			}
			pw_seed_meta( $id, 'avis', array(
				'entreprise'   => $r['company'],
				'mis_en_avant' => $r['featured'] ? '1' : '0',
				'citation_fr'  => $r['quote']['fr'],
				'citation_en'  => $r['quote']['en'],
				'citation_es'  => $r['quote']['es'],
			) );
			$count++;
		}
	}

	if ( pw_seed_is_empty( 'pw_faq' ) ) {
		foreach ( $data['faq'] as $i => $f ) {
			$id = pw_seed_insert( 'pw_faq', $f['question']['fr'], $i );
			if ( ! $id ) {
				continue;
			}
			pw_seed_meta( $id, 'faq', array(
				'question_en' => $f['question']['en'],
				'question_es' => $f['question']['es'],
				'reponse_fr'  => $f['answer']['fr'],
				'reponse_en'  => $f['answer']['en'],
				'reponse_es'  => $f['answer']['es'],
				'ouverte'     => $f['open'] ? '1' : '0',
			) );
			$count++;
		}
	}

	if ( pw_seed_is_empty( 'pw_formule' ) ) {
		foreach ( $data['pricing'] as $i => $f ) {
			$id = pw_seed_insert( 'pw_formule', $f['name']['fr'], $i );
			if ( ! $id ) {
				continue;
			}
			pw_seed_meta( $id, 'formule', array(
				'nom_en'         => $f['name']['en'],
				'nom_es'         => $f['name']['es'],
				'mise_en_avant'  => $f['featured'] ? '1' : '0',
				'prix_fr'        => $f['price']['fr'],
				'prix_en'        => $f['price']['en'],
				'prix_es'        => $f['price']['es'],
				'description_fr' => $f['desc']['fr'],
				'description_en' => $f['desc']['en'],
				'description_es' => $f['desc']['es'],
				'elements_fr'    => implode( "\n", $f['items']['fr'] ),
				'elements_en'    => implode( "\n", $f['items']['en'] ),
				'elements_es'    => implode( "\n", $f['items']['es'] ),
			) );
			$count++;
		}
	}

	delete_transient( 'pw_build_lock' );
	if ( $count ) {
		pw_trigger_build();
	}
	wp_safe_redirect( admin_url( 'tools.php?page=pw-seed&pw_seeded=' . $count ) );
	exit;
} );
