<?php
/**
 * Champs ACF déclarés en PHP : rien à configurer dans l'admin.
 * Chaque texte existe en français (_fr), en anglais (_en) et en espagnol (_es).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Raccourci pour déclarer un champ.
 */
function pw_field( $group, $name, $label, $type = 'text', $extra = array() ) {
	return array_merge( array(
		'key'   => 'field_pw_' . $group . '_' . $name,
		'name'  => $name,
		'label' => $label,
		'type'  => $type,
	), $extra );
}

function pw_group( $key, $title, $post_type, $fields ) {
	acf_add_local_field_group( array(
		'key'                   => 'group_pw_' . $key,
		'title'                 => $title,
		'fields'                => $fields,
		'location'              => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => $post_type ) ) ),
		'position'              => 'acf_after_title',
		'style'                 => 'seamless',
		'label_placement'       => 'top',
		'instruction_placement' => 'label',
	) );
}

add_action( 'acf/init', function () {

	$third = array( 'wrapper' => array( 'width' => 33 ) );
	$half  = array( 'wrapper' => array( 'width' => 50 ) );
	$lines = array( 'rows' => 6, 'instructions' => 'Un élément par ligne.' );
	$area  = function ( $rows ) use ( $third ) {
		return array_merge( $third, array( 'rows' => $rows ) );
	};

	// ---------- Projets (capture 1440 × 900 = image mise en avant) ----------
	pw_group( 'projet', 'Projet', 'pw_projet', array(
		pw_field( 'projet', 'url', 'Adresse du site', 'url', $half ),
		pw_field( 'projet', 'domaine', 'Domaine affiché (ex. axotime.com)', 'text', $half ),
		pw_field( 'projet', 'type_fr', 'Type (FR) — ex. Site vitrine', 'text', $third ),
		pw_field( 'projet', 'type_en', 'Type (EN) — ex. Business website', 'text', $third ),
		pw_field( 'projet', 'type_es', 'Type (ES) — ex. Web corporativa', 'text', $third ),
		pw_field( 'projet', 'description_fr', 'Description (FR)', 'textarea', $area( 3 ) ),
		pw_field( 'projet', 'description_en', 'Description (EN)', 'textarea', $area( 3 ) ),
		pw_field( 'projet', 'description_es', 'Description (ES)', 'textarea', $area( 3 ) ),
	) );

	// ---------- Avis (logo de l'entreprise = image mise en avant) ----------
	pw_group( 'avis', 'Avis', 'pw_avis', array(
		pw_field( 'avis', 'entreprise', 'Entreprise', 'text', $half ),
		pw_field( 'avis', 'mis_en_avant', 'Mettre en avant (carte en dégradé)', 'true_false', array_merge( $half, array( 'ui' => 1 ) ) ),
		pw_field( 'avis', 'citation_fr', 'Avis (FR)', 'textarea', $area( 4 ) ),
		pw_field( 'avis', 'citation_en', 'Avis (EN)', 'textarea', $area( 4 ) ),
		pw_field( 'avis', 'citation_es', 'Avis (ES)', 'textarea', $area( 4 ) ),
	) );

	// ---------- FAQ ----------
	pw_group( 'faq', 'Question', 'pw_faq', array(
		pw_field( 'faq', 'question_en', 'Question (EN)', 'text', $half ),
		pw_field( 'faq', 'question_es', 'Question (ES)', 'text', $half ),
		pw_field( 'faq', 'reponse_fr', 'Réponse (FR)', 'textarea', $area( 4 ) ),
		pw_field( 'faq', 'reponse_en', 'Réponse (EN)', 'textarea', $area( 4 ) ),
		pw_field( 'faq', 'reponse_es', 'Réponse (ES)', 'textarea', $area( 4 ) ),
		pw_field( 'faq', 'ouverte', 'Ouverte par défaut', 'true_false', array( 'ui' => 1 ) ),
	) );

	// ---------- Formules ----------
	pw_group( 'formule', 'Formule', 'pw_formule', array(
		pw_field( 'formule', 'nom_en', 'Nom (EN)', 'text', $third ),
		pw_field( 'formule', 'nom_es', 'Nom (ES)', 'text', $third ),
		pw_field( 'formule', 'mise_en_avant', 'Mettre en avant (carte en dégradé)', 'true_false', array_merge( $third, array( 'ui' => 1 ) ) ),
		pw_field( 'formule', 'prix_fr', 'Prix (FR) — ex. 499 €', 'text', $third ),
		pw_field( 'formule', 'prix_en', 'Prix (EN) — ex. €499', 'text', $third ),
		pw_field( 'formule', 'prix_es', 'Prix (ES) — ex. 499 €', 'text', $third ),
		pw_field( 'formule', 'description_fr', 'Description (FR)', 'textarea', $area( 2 ) ),
		pw_field( 'formule', 'description_en', 'Description (EN)', 'textarea', $area( 2 ) ),
		pw_field( 'formule', 'description_es', 'Description (ES)', 'textarea', $area( 2 ) ),
		pw_field( 'formule', 'elements_fr', 'Ce qui est inclus (FR)', 'textarea', array_merge( $third, $lines ) ),
		pw_field( 'formule', 'elements_en', 'Ce qui est inclus (EN)', 'textarea', array_merge( $third, $lines ) ),
		pw_field( 'formule', 'elements_es', 'Ce qui est inclus (ES)', 'textarea', array_merge( $third, $lines ) ),
	) );

	// Les clients n'ont pas de champ : nom = titre, logo = image mise en avant.
} );
