<?php
/**
 * Reconstruction automatique du site Astro sur Netlify.
 *
 * Quand un contenu Peleweb est publié, modifié ou retiré, WordPress appelle
 * le « build hook » Netlify (constante PELEWEB_BUILD_HOOK dans wp-config.php).
 * Un bouton « Mettre le site à jour » est aussi ajouté dans la barre d'admin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function pw_trigger_build() {
	if ( ! defined( 'PELEWEB_BUILD_HOOK' ) || ! PELEWEB_BUILD_HOOK ) {
		return false;
	}
	// Une seule reconstruction par minute, même si plusieurs contenus sont enregistrés à la suite.
	if ( get_transient( 'pw_build_lock' ) ) {
		return true;
	}
	set_transient( 'pw_build_lock', 1, MINUTE_IN_SECONDS );
	wp_remote_post( PELEWEB_BUILD_HOOK, array(
		'timeout'  => 5,
		'blocking' => false,
		'body'     => '{}',
	) );
	return true;
}

add_action( 'transition_post_status', function ( $new, $old, $post ) {
	$types = array( 'pw_projet', 'pw_client', 'pw_avis', 'pw_formule', 'pw_faq' );
	if ( ! in_array( $post->post_type, $types, true ) ) {
		return;
	}
	if ( 'publish' === $new || 'publish' === $old ) {
		pw_trigger_build();
	}
}, 10, 3 );

// Bouton manuel dans la barre d'administration.
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( ! current_user_can( 'edit_posts' ) || ! defined( 'PELEWEB_BUILD_HOOK' ) ) {
		return;
	}
	$bar->add_node( array(
		'id'    => 'pw-build',
		'title' => 'Mettre le site à jour',
		'href'  => wp_nonce_url( admin_url( 'admin-post.php?action=pw_build' ), 'pw_build' ),
	) );
}, 100 );

add_action( 'admin_post_pw_build', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'pw_build' ) ) {
		wp_die( 'Action non autorisée.' );
	}
	delete_transient( 'pw_build_lock' );
	$ok = pw_trigger_build();
	wp_safe_redirect( add_query_arg( 'pw_build', $ok ? 'ok' : 'missing', wp_get_referer() ? wp_get_referer() : admin_url() ) );
	exit;
} );

add_action( 'admin_notices', function () {
	if ( empty( $_GET['pw_build'] ) ) {
		return;
	}
	if ( 'ok' === $_GET['pw_build'] ) {
		echo '<div class="notice notice-success is-dismissible"><p>Mise à jour du site lancée : elle sera en ligne dans une à deux minutes.</p></div>';
	} else {
		echo '<div class="notice notice-error is-dismissible"><p>La constante PELEWEB_BUILD_HOOK n’est pas définie dans wp-config.php.</p></div>';
	}
} );
