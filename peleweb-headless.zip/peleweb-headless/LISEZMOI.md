# Peleweb — WordPress headless + Astro

Ce dossier contient tout le nécessaire pour mettre en ligne peleweb.com :

| Dossier | Rôle |
|---|---|
| `astro/` | Le site public (FR/EN/ES, sombre/clair). Hébergé gratuitement sur Netlify. |
| `wordpress/peleweb-headless/` | Le thème WordPress « headless » : WordPress ne sert plus qu'à gérer les contenus. |
| `wordpress/peleweb-headless-theme.zip` | Le même thème, prêt à téléverser dans WordPress. |

**Comment ça marche :** vous modifiez un projet, un avis, une question de FAQ ou une formule dans WordPress. WordPress prévient Netlify, qui reconstruit le site Astro en une à deux minutes. Les visiteurs ne voient jamais WordPress.

```
WordPress (cms.peleweb.com)  ──contenus──▶  Astro (build sur Netlify)  ──▶  peleweb.com
```

---

## Étape 1 — Tester le site sur votre ordinateur (sans WordPress)

Le site fonctionne tout seul, avec les contenus de départ de `astro/src/data/fallback.json`.

1. Installez **Node.js** depuis nodejs.org : il faut la **version 22.23.4 ou plus récente** (Astro 7 l'exige).
2. Ouvrez un terminal dans le dossier `astro/` (dans VS Code : clic droit sur le dossier › « Ouvrir dans le terminal intégré »).
3. Tapez :
   ```
   npm install
   npm run dev
   ```
4. Ouvrez **http://localhost:4321** (français), **http://localhost:4321/en/** (anglais) et **http://localhost:4321/es/** (espagnol).

Chaque modification de fichier s'affiche immédiatement dans le navigateur.

---

## Étape 2 — Installer WordPress sur un sous-domaine

WordPress a besoin d'un hébergement PHP : Netlify n'en fournit pas. Gardez une petite offre d'hébergement (OVH ou autre) pour le CMS uniquement.

1. Chez OVH, dans votre hébergement, ajoutez le sous-domaine **cms.peleweb.com** (Multisite › Ajouter un domaine), avec son propre dossier, par exemple `cms/`.
2. Installez un WordPress neuf dans ce dossier, avec une base de données vide.
3. Dans WordPress :
   - **Réglages › Lecture** : cochez « Demander aux moteurs de recherche de ne pas indexer ce site ».
   - **Réglages › Permaliens** : choisissez « Titre de la publication » (indispensable pour l'API).
   - **Extensions › Ajouter** : installez et activez **Advanced Custom Fields** (version gratuite).
   - **Apparence › Thèmes › Ajouter › Téléverser** : envoyez `wordpress/peleweb-headless-theme.zip`, puis activez-le.
   - **Outils › Contenus Peleweb** : cliquez sur « Importer les contenus de départ ». Les projets, clients, avis, la FAQ et les formules sont créés en français, anglais et espagnol.
   - Ajoutez ensuite les images : la capture de chaque projet et le logo de chaque client et de chaque avis, dans « Image mise en avant ». Les fichiers sont dans `astro/public/images/`.
4. Vérifiez l'API en ouvrant **https://cms.peleweb.com/wp-json/peleweb/v1/content** : vous devez voir vos contenus au format JSON.

Dans l'admin, vous trouvez maintenant les menus **Projets, Clients (logos), Avis clients, Formules et FAQ**. L'ordre d'affichage se règle avec le champ « Ordre » (bloc Attributs, à droite).

---

## Étape 3 — Mettre le code sur GitHub

1. Installez **GitHub Desktop** et connectez-vous.
2. **File › Add local repository** › choisissez le dossier `astro/` › « Create a repository ».
3. Cliquez sur **Publish repository** (vous pouvez le garder privé).

À chaque modification du code : GitHub Desktop › écrire un résumé › **Commit** › **Push**.

---

## Étape 4 — Mettre le site en ligne sur Netlify

1. Sur netlify.com : **Add new site › Import an existing project › GitHub** › choisissez le dépôt.
2. Les réglages de build sont lus automatiquement dans `netlify.toml` : ne changez rien.
3. Avant de lancer le déploiement, ajoutez une **variable d'environnement** :
   - Nom : `WP_API_URL`
   - Valeur : `https://cms.peleweb.com`
4. Lancez le déploiement. Le site est visible sur une adresse provisoire du type `peleweb.netlify.app`.

> Si WordPress ne répond pas pendant un build, le build échoue volontairement : Netlify garde alors la version en ligne au lieu de publier un site vide.

---

## Étape 5 — Relier WordPress à Netlify (mise à jour automatique)

1. Sur Netlify : **Site configuration › Build & deploy › Build hooks › Add build hook**, nommez-le « WordPress », puis copiez l'adresse générée.
2. Dans le fichier `wp-config.php` de WordPress, au-dessus de la ligne « C'est tout, ne touchez pas à ce qui suit », ajoutez :
   ```php
   define( 'PELEWEB_FRONTEND_URL', 'https://peleweb.com' );
   define( 'PELEWEB_BUILD_HOOK', 'https://api.netlify.com/build_hooks/VOTRE_IDENTIFIANT' );
   ```
3. Désormais, chaque publication ou modification d'un contenu relance le site. Un bouton **« Mettre le site à jour »** est aussi disponible dans la barre noire en haut de l'admin.

---

## Étape 6 — Brancher peleweb.com

1. Sur Netlify : **Domain management › Add a domain** › `peleweb.com`. Netlify affiche les enregistrements DNS à créer.
2. Chez OVH, dans **Noms de domaine › peleweb.com › Zone DNS** :
   - modifiez l'enregistrement **A** de `peleweb.com` avec l'adresse IP indiquée par Netlify ;
   - modifiez le **CNAME** de `www` pour qu'il pointe vers votre adresse `xxx.netlify.app` ;
   - **ne touchez pas aux enregistrements MX** : vos emails continuent de fonctionner ;
   - gardez l'enregistrement de `cms` qui pointe vers votre hébergement OVH.
3. Le certificat HTTPS est créé automatiquement par Netlify (comptez jusqu'à quelques heures pour la propagation DNS).

---

## Au quotidien : où modifier quoi ?

| Je veux modifier… | Où ? |
|---|---|
| Un projet, sa capture, un logo client, un avis, la FAQ, une formule | Dans **WordPress** : le site se met à jour tout seul.<br>Sans WordPress : `astro/src/data/fallback.json` et les images de `astro/public/images/`. |
| Les textes de la page (titres, services, méthode, maintenance, CTA…) | `astro/src/i18n/fr.json`, `en.json` et `es.json`, puis Commit + Push. |
| Les couleurs, polices, animations | `astro/src/styles/global.css` (les couleurs sont en haut, dans `:root`). |
| La structure d'une section | `astro/src/components/` : un fichier par section (`Hero.astro`, `Services.astro`…). |
| Les mentions légales | `astro/src/components/Legal.astro` (textes entre crochets à compléter). |

Pour modifier un texte sans rien installer, vous pouvez aussi ouvrir le fichier directement sur github.com, cliquer sur le crayon, puis « Commit changes » : Netlify redéploie automatiquement.

### Images

- **Captures des projets** : image mise en avant du projet, au format **1440 × 900 px** (WebP de préférence). WordPress crée aussi automatiquement une version 720 × 450 pour le mobile.
- **Logos clients** : SVG ou PNG à fond transparent, recadrés au plus près du logo. Ils s'affichent sur fond blanc, à 56 px de haut maximum.

### Bon à savoir

- **Thème sombre / clair** : le site suit le réglage de l'appareil du visiteur, et le bouton soleil/lune mémorise son choix.
- **Polices** : elles sont chargées depuis Google Fonts. Pour une conformité RGPD renforcée, on pourra les héberger directement sur le site.
- **À compléter** : les mentions légales (FR, EN et ES) et votre photo dans la section Approche.
